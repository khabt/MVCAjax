var densityCanvas = document.getElementById("densityChart");

Chart.defaults.global.defaultFontFamily = "Lato";
Chart.defaults.global.defaultFontSize = 18;

var densityData = {
    label: 'USD',
    data: ['5427', 5243, 5514, 3933, 1326, 687, 1271, 1638],
    backgroundColor: [
     'rgba(0, 99, 132, 0.6)',
     'rgba(30, 99, 132, 0.6)',
     'rgba(60, 99, 132, 0.6)',
     'rgba(90, 99, 132, 0.6)',
     'rgba(120, 99, 132, 0.6)',
     'rgba(150, 99, 132, 0.6)',
     'rgba(180, 99, 132, 0.6)',
     'rgba(210, 99, 132, 0.6)',
     'rgba(240, 99, 132, 0.6)'
    ],
    bezierCurve: false,
    animation: false
};

var barChart = new Chart(densityCanvas, {
    type: 'bar',
    data: {
        labels: ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"],
        datasets: [densityData],
        backgroundColor: [
       'rgba(0, 111111, 132, 0.6)',
       'rgba(30, 99, 132, 0.6)',
       'rgba(60, 99, 132, 0.6)',
       'rgba(90, 99, 132, 0.6)',
       'rgba(120, 99, 132, 0.6)',
        ]
    },
    options: {
        tooltips: {
            callbacks: {
                label: function (tooltipItem, data) {
                    var value = data.datasets[0].data[tooltipItem.index];
                    value = value.toString();
                    value = value.split(/(?=(?:...)*$)/);
                    value = value.join(',');
                    return value;
                }
            } // end callbacks:
        }, //end tooltips
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    userCallback: function (value, index, values) {
                        // Convert the number to a string and splite the string every 3 charaters from the end
                        value = value.toString();
                        value = value.split(/(?=(?:...)*$)/);
                        value = value.join(',');
                        return value;
                    }
                }
            }],
            xAxes: [{
                ticks: {
                }
            }]
        }
    },
    plugins: [{
        afterRender: function () {
            // Do anything you want
            renderIntoImage()
        },
    }],
});

const renderIntoImage = () => {
    const canvas = document.getElementById('densityChart')
    const imgWrap = document.getElementById('url')
    var img = new Image();
    imgWrap.src = canvas.toDataURL();    
    canvas.style.display = 'none';
}



//function done() {
//    var url = myLine.toBase64Image();
//    document.getElementById("url").src = url;
//}
//var options = {
//    bezierCurve: false,
//    animation: {
//        onComplete: done
//    }
//};


//var myLine = new Chart(document.getElementById("densityChart").getContext("2d"), {
//    data: densityData,
//    type: "bar",
//    options: options
//});


